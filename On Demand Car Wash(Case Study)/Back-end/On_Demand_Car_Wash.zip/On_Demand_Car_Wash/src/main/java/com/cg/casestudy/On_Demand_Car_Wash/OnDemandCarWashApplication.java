package com.cg.casestudy.On_Demand_Car_Wash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnDemandCarWashApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnDemandCarWashApplication.class, args);
	}

}
