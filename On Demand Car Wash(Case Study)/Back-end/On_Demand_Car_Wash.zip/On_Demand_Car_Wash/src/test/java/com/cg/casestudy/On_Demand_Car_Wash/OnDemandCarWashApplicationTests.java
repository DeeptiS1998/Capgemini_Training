package com.cg.casestudy.On_Demand_Car_Wash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnDemandCarWashApplicationTests {

	@Test
	void contextLoads() {
	}

}
